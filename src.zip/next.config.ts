/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['videos.sproutvideo.com'],
  },
};

module.exports = nextConfig;